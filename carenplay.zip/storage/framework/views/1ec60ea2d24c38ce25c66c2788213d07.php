<?php $__env->startSection('content'); ?>
    <main class="main-block">
        <?php if(session('success')): ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Siker!',
                    text: '<?php echo e(session('success')); ?>',
                    confirmButtonText: 'OK'
                });
            </script>
        <?php endif; ?>
        <div class="home-page">
            <div class="content" id="content">
                <section>
                    <div class="py-3 fs-5">
                        <h2 class="text-center display-5">Üdvözöljük, <?php echo e(Auth::user()->username); ?> !</h2>
                        <p><b>Email:</b> <a href="mailto:<?php echo e(Auth::user()->Email); ?>"><?php echo e(Auth::user()->email); ?></a></p>
                        <p><a class="btn btn-info" href="/newpass">Jelszó módosítás</a></p>
                        <p><a class="btn btn-danger" href="/logout">Kilépés</a></p>
                    </div>
                </section>

            </div>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Domin\Desktop\IT\school\2024-25\VizsgaRemek\vizsgremek\CarenPlay\resources\views/profil.blade.php ENDPATH**/ ?>