<?php $__env->startSection('content'); ?>
    <main class="main-block">
        <?php if(session('error')): ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Sikertelen',
                    text: '<?php echo e(session('error')); ?>',
                    confirmButtonText: 'OK'
                });
            </script>
        <?php endif; ?>
        <div class="home-page">
            <div class="content" id="content">
                <div class="regpage">
                    <div class="formcard hidden d-grid justify-content-center align-items-center  " id="animatedDiv">
                        <h2>Új jelszó igénylése</h2>
                        <div class="rightreg">
                            <div class="righregcontent">
                                <form action="/newpass" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="py-2 ">
                                        <label for="oldpassword" class="form-label text-center w-100">Régi jelszó: </label>
                                        <input type="password" name="oldpassword" id="oldpassword"
                                            class="form-control w-50 rounded-pill mx-auto ">
                                        <?php $__errorArgs = ['oldpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="py-2">
                                        <label for="newpassword" class="form-label text-center w-100">Új Jelszó: </label>
                                        <input type="password" name="newpassword" id="newpassword"
                                            class="form-control w-50 rounded-pill mx-auto ">
                                        <?php $__errorArgs = ['newpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="py-2">
                                        <label for="newpassword_confirmation" class="form-label text-center w-100">Új Jelszó
                                            mégegyszer:
                                        </label>
                                        <input type="password" name="newpassword_confirmation" id="newpassword_confirmation"
                                            class="form-control w-50 rounded-pill mx-auto ">
                                        <?php $__errorArgs = ['newpassword_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="py-2 mx-auto">
                                        <button class="btn w-100 text-center mx-auto " type="submit">Jelszó
                                            módosítása</button>
                                    </div>




                                </form>
                            </div>

                        </div>
                    </div>
                </div>


            </div>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Domin\Desktop\IT\school\2024-25\VizsgaRemek\vizsgremek\CarenPlay\resources\views/newpass.blade.php ENDPATH**/ ?>