<?php $__env->startSection('content'); ?>
    <main class="main-block">
        <div class="home-page">
            <div class="content" id="content">
                <div class="regpage">
                    <div class="row formcard hidden" id="animatedDiv">
                        <h2>Regisztráció</h2>
                        <hr>
                        <div class="col-md-6 leftreg p-5">
                            <form action="/reg" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="py-3">
                                    <label for="nev" id="nev" class="form-label ">Név:</label>
                                    <input type="text" name="nev" id="nev"
                                        class="form-control w-100 rounded-pill" placeholder="Pl. Gipsz Jakab"
                                        value=<?php echo e(old('nev')); ?>>
                                    <?php $__errorArgs = ['nev'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"> <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="py-3">
                                    <label for="email" id="email" class="form-label">Email:</label>
                                    <input type="email" name="email" id="email"
                                        class="form-control w-100 rounded-pill" placeholder="Pl. gipszjakab2@gmail.com"
                                        value=<?php echo e(old('email')); ?>>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"> <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="py-3">
                                    <label for="password" id="password" class="form-label">Jelszó:</label>
                                    <input type="password" name="password" id="password"
                                        class="form-control w-100 rounded-pill" placeholder="Pl. GipszJakab01.">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"> <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="py-3">
                                    <label for="password_confirmation" id="password_confirmation" class="form-label">Jelszó
                                        mégegyszer:</label>
                                    <input type="password" name="password_confirmation" id="password_confirmation"
                                        class="form-control w-100 rounded-pill" placeholder="Pl. GipszJakab01.">
                                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"> <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="py-3 text-center">
                                    <button type="submit" class="btn ">Regisztráció!</button>
                                </div>

                        </div>
                        <div class="col-md-6 rightreg p-5">
                            <div class="righregcontent py-auto">
                                <h3>Már van fiókod?</h3>
                                <p>Jelentkezz be!</p>
                                <a href="/login" class="btn">Belépés!</a>
                            </div>

                        </div>
                    </div>
                    </form>
                </div>





            </div>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Domin\Desktop\IT\school\2024-25\VizsgaRemek\vizsgremek\CarenPlay\resources\views/reg.blade.php ENDPATH**/ ?>