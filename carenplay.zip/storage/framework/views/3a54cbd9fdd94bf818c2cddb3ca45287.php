<?php $__env->startSection('content'); ?>
    <main class="main-block">
        <?php if(session('error')): ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Sikertelen bejelentkezés!',
                    text: '<?php echo e(session('error')); ?>',
                    confirmButtonText: 'OK'
                });
            </script>
        <?php endif; ?>
        <div class="home-page">
            <div class="content" id="content">
                <div class="regpage">
                    <div class="row formcard  hidden" id="animatedDiv">
                        <h2>Bejelentkezés</h2>
                        <hr>
                        <div class="col-md-6 leftreg p-5">
                            <div class="righregcontent">
                                <form action="/login" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="py-3">
                                        <label for="credentials" id="credentials" class="form-label">Email vagy
                                            felhasznlónév:</label>
                                        <input type="text" name="credentials" id="credentials"
                                            class="form-control w-100 rounded-pill" value=<?php echo e(old('credentials')); ?>>
                                        <?php $__errorArgs = ['credentials'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="py-3">
                                        <label for="password" id="password" class="form-label">Jelszó:</label>
                                        <input type="password" name="password" id="password"
                                            class="form-control w-100 rounded-pill">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="py-3">
                                        <button type="submit" class="btn">Belépés!</button>
                                    </div>

                            </div>

                        </div>
                        <div class="col-md-6 rightreg">

                            <div class="righregcontent text-center">
                                <h3>Még nincs fiókod?</h3>
                                <p>Regisztrálj be!</p>
                                <a href="/reg" class="btn">Regisztráció!</a>
                            </div>
                        </div>
                        </form>
                    </div>

                </div>



    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Domin\Desktop\IT\school\2024-25\VizsgaRemek\vizsgremek\CarenPlay\resources\views/login.blade.php ENDPATH**/ ?>